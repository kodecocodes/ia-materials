//
//  ChecklistItem.swift
//  Checklist
//
//  Created by Joey deVilla on 4/29/20.
//  Copyright © 2020 Joey deVilla. All rights reserved.
//

import Foundation


struct ChecklistItem: Identifiable {
  let id = UUID()
  var name: String
  var isChecked: Bool = false
}
