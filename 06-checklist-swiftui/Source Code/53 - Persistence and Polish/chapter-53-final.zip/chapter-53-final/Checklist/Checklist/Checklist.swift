//
//  Checklist.swift
//  Checklist
//
//  Created by Joey deVilla on 4/29/20.
//  Copyright © 2020 Joey deVilla. All rights reserved.
//

import Foundation


class Checklist: ObservableObject {

  // Properties
  // ==========

  @Published var items: [ChecklistItem] = []


  // Methods
  // =======

  init() {
    loadChecklistItems()
  }
  
  func deleteListItem(whichElement: IndexSet) {
    items.remove(atOffsets: whichElement)
    saveChecklistItems()
  }

  func moveListItem(whichElement: IndexSet, destination: Int) {
    items.move(fromOffsets: whichElement, toOffset: destination)
    saveChecklistItems()
  }

  func printChecklistContents() {
    for item in items {
      print(item)
    }
  }

  // MARK: File management

  func documentsDirectory() -> URL {
    let paths = FileManager.default.urls(for: .documentDirectory,
                                         in: .userDomainMask)
    let directory = paths[0]
    print("Documents directory is: \(directory)")
    return directory
  }

  func dataFilePath() -> URL {
    let filePath = documentsDirectory().appendingPathComponent("Checklist.plist")
    print("Data file path is: \(filePath)")
    return filePath
  }

  func saveChecklistItems() {
    // 1
    print("Saving checklist items")
    // 2
    let encoder = PropertyListEncoder()
    // 3
    do {
      // 4
      let data = try encoder.encode(items)
      // 5
      try data.write(to: dataFilePath(),
                     options: Data.WritingOptions.atomic)
      // 6
      print("Checklist items saved")
      // 7
    } catch {
      print("Error encoding item array: \(error.localizedDescription)")
    }
  }

  func loadChecklistItems() {
    // 1
    print("Loading checklist items")
    // 2
    let path = dataFilePath()
    // 3
    if let data = try? Data(contentsOf: path) {
      // 4
      let decoder = PropertyListDecoder()
      do {
        // 5
        items = try decoder.decode([ChecklistItem].self,
                                   from: data)
        // 6
        print("Checklist items loaded")
        // 7
      } catch {
        print("Error decoding item array: \(error.localizedDescription)")
      }
    }
  }

}
