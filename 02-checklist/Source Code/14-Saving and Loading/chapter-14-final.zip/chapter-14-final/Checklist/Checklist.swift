/// Copyright (c) 2019 Razeware LLC
///
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
///
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
///
/// Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
/// distribute, sublicense, create a derivative work, and/or sell copies of the
/// Software in any work that is designed, intended, or marketed for pedagogical or
/// instructional purposes related to programming, coding, application development,
/// or information technology.  Permission for such use, copying, modification,
/// merger, publication, distribution, sublicensing, creation of derivative works,
/// or sale is expressly withheld.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.

import Foundation

class Checklist: ObservableObject {
  
  // Properties
  // ==========
  
  @Published var items = [
    ChecklistItem(name: "Walk the dog", isChecked: false),
    ChecklistItem(name: "Brush my teeth", isChecked: false),
    ChecklistItem(name: "Learn iOS development", isChecked: true),
    ChecklistItem(name: "Soccer practice", isChecked: false),
    ChecklistItem(name: "Eat ice cream", isChecked: true),
  ]

  
  // Methods
  // =======

  init() {
    print("Documents directory is: \(documentsDirectory())")
    print("Data file path is: \(dataFilePath())")
    loadListItems()
  }
  
  func printChecklistContents() {
    for item in items {
      print(item)
    }
    print("===================")
  }

  func deleteListItem(whichElement: IndexSet) {
    items.remove(atOffsets: whichElement)
    printChecklistContents()
    saveListItems()
  }

  func moveListItem(whichElement: IndexSet, destination: Int) {
    items.move(fromOffsets: whichElement, toOffset: destination)
    printChecklistContents()
    saveListItems()
  }

  func documentsDirectory() -> URL {
    let paths = FileManager.default.urls(for: .documentDirectory,
                                          in: .userDomainMask)
    return paths[0]
  }

  func dataFilePath() -> URL {
    return documentsDirectory().appendingPathComponent("Checklist.plist")
  }

  func saveListItems() {
    // 1
    let encoder = PropertyListEncoder()
    // 2
    do {
      // 3
      let data = try encoder.encode(items)
      // 4
      try data.write(to: dataFilePath(),
                options: Data.WritingOptions.atomic)
      // 5
    } catch {
      // 6
      print("Error encoding item array: \(error.localizedDescription)")
    }
  }

  func loadListItems() {
    // 1
    let path = dataFilePath()
    // 2
    if let data = try? Data(contentsOf: path) {
      // 3
      let decoder = PropertyListDecoder()
      do {
        // 4
        items = try decoder.decode([ChecklistItem].self,
                                   from: data)
        // 5
      } catch {
        print("Error decoding item array: \(error.localizedDescription)")
      }
    }
  }
  
}
