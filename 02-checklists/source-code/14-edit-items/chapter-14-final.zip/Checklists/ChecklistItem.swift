//
//  ChecklistItem.swift
//  Checklists
//
//  Created by Fahim Farook on 30/07/2020.
//  Copyright © 2020 Razeware. All rights reserved.
//

import Foundation

class ChecklistItem: NSObject {
  var text = ""
  var checked = false
}
